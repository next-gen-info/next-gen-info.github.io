---
layout: post
title: A Example Post
date: 2019-01-01 00:00:00 +0800
category: tutorial
thumbnail: /style/image/thumbnail.png
icon: book
---


* content
{:toc}

## sub title

page...

## about thumbnail

add the thumbnail url

## about icon

such as book, code, web, chat, note, game, link, design, image